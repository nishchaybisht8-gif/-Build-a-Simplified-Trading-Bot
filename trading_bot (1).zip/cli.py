from bot.client import get_client
from bot.orders import place_market_order, place_limit_order, place_stop_limit_order
from bot.logging_config import setup_logging
from bot.validators import validate_symbol, validate_quantity, validate_price

def main():
    setup_logging()
    client = get_client()

    while True:
        print("\n=== TRADING BOT ===")
        print("1. Market Order")
        print("2. Limit Order")
        print("3. Stop-Limit Order")
        print("4. Exit")

        choice = input("Select option: ")

        if choice == "4":
            break

        try:
            symbol = input("Symbol (BTCUSDT): ").upper()
            validate_symbol(symbol)

            side = input("Side (BUY/SELL): ").upper()
            quantity = input("Quantity: ")
            validate_quantity(quantity)

            if choice == "1":
                place_market_order(client, symbol, side, quantity)

            elif choice == "2":
                price = input("Price: ")
                validate_price(price)
                place_limit_order(client, symbol, side, quantity, price)

            elif choice == "3":
                price = input("Limit Price: ")
                stop_price = input("Stop Price: ")
                validate_price(price)
                validate_price(stop_price)
                place_stop_limit_order(client, symbol, side, quantity, price, stop_price)

        except Exception as e:
            print("Error:", e)

if __name__ == "__main__":
    main()
