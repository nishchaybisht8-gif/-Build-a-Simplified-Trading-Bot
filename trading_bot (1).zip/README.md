# Trading Bot (Binance Testnet)

## Setup
pip install -r requirements.txt

Create .env:
API_KEY=your_key
API_SECRET=your_secret

Run:
python cli.py

## Features
- Market Orders
- Limit Orders
- Stop-Limit Orders
- Logging

Logs saved in logs/trading.log
