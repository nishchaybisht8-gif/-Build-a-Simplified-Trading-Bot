def validate_symbol(symbol):
    if not symbol or len(symbol) < 5:
        raise ValueError("Invalid symbol (e.g., BTCUSDT)")

def validate_quantity(quantity):
    if float(quantity) <= 0:
        raise ValueError("Quantity must be positive")

def validate_price(price):
    if float(price) <= 0:
        raise ValueError("Price must be positive")
