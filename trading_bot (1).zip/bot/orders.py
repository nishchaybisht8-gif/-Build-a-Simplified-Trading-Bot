import logging

def place_market_order(client, symbol, side, quantity):
    try:
        order = client.order_market(
            symbol=symbol,
            side=side,
            quantity=quantity
        )
        logging.info(f"MARKET ORDER SUCCESS: {order}")
        return order
    except Exception as e:
        logging.error(f"Market order failed: {e}")

def place_limit_order(client, symbol, side, quantity, price):
    try:
        order = client.order_limit(
            symbol=symbol,
            side=side,
            quantity=quantity,
            price=price,
            timeInForce='GTC'
        )
        logging.info(f"LIMIT ORDER SUCCESS: {order}")
        return order
    except Exception as e:
        logging.error(f"Limit order failed: {e}")

def place_stop_limit_order(client, symbol, side, quantity, price, stop_price):
    try:
        order = client.create_order(
            symbol=symbol,
            side=side,
            type="STOP_LOSS_LIMIT",
            quantity=quantity,
            price=price,
            stopPrice=stop_price,
            timeInForce="GTC"
        )
        logging.info(f"STOP-LIMIT ORDER SUCCESS: {order}")
        return order
    except Exception as e:
        logging.error(f"Stop-limit order failed: {e}")
